# ChatRobo
A simple chatbot built with HTML, CSS, and JavaScript.  
[Live Demo](https://parthkalumali-1.github.io/chatbot-1)

## Features
- Light/Dark theme toggle
- Dynamic bot responses with commands like `/joke`, `/time`, and `/weather`
- Responsive and accessible design

## How to Run Locally
Clone this repository and open `index.html` in your browser.
